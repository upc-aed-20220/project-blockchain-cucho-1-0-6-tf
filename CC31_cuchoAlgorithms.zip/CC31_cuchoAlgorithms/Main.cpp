#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<stdlib.h>
#include <vector>
#include <list>
#include <utility> 
#include <math.h>
#include<time.h>

using namespace std;

const int maxColision = 3;
const float maxFillFactor = 0.5;
#include "Arbol.h"

template <class T>
class Node {
public:
    T valor;
    Node* siguiente;
    Node* anterior;
    Node(T valor = 0, Node* siguiente = nullptr, Node* anterior = nullptr) :valor(valor), siguiente(siguiente), anterior(anterior) {
    }
};
template<class T>
class BC {
private:
    Node<T>* inicio;
    Node<T>* fin;
    size_t cant;
public:
    class iterator {
    private:
        long pos;
        Node<T>* aux;
    public:
        iterator(long pos = 0, Node<T>* aux = nullptr) {
            this->pos = pos;
            this->aux = aux;

        }

        bool operator !=(iterator x) { return this->pos != x.pos; };
        void operator ++() { pos++; aux = aux->siguiente; };
        T operator*() {
            return aux->valor;
        }
    };

    iterator begin() {
        return iterator(0, inicio);
    }
    iterator end() {
        return iterator(cant, nullptr);
    }


    BC() {
        inicio = fin = nullptr;
        cant = 0;
    }
    void push_back(T valor) {
        Node<T>* nuevo = new Node<T>(valor);
        if (cant == 0) {
            inicio = fin = nuevo;
        }
        else {
            fin->siguiente = nuevo;
            nuevo->anterior = fin;
            fin = nuevo;
        }
        ++cant;
    }

    size_t getCant() { return cant; }

    void cambiarMensaje(Node<T>*& nodo_pasa) {
        char a;
        int c = 0;
        Node<T>* aux = nodo_pasa;
        string msg;
        //while (aux != nullptr) {
        msg = aux->valor->getU();
        for (int i = 0; i < msg.length(); i++) {

            a = msg.at(i);
            cout << (int)a;
            ++c;
        }

        // }
    }


    void printdatos() {
        Node<T>* aux = inicio;
        while (aux != nullptr) {
            cout << endl << endl;
            cout << "Anterior:" << endl;
            if (aux->anterior == nullptr) {
                cout << "nullptr" << endl;
            }
            else {
                aux->anterior->valor->print();
            }
            cout << "Valor: " << endl;
            aux->valor->print();
            cout << "Hash(Valor): " << endl;
            cambiarMensaje(aux);
            cout << "\nsiguiente: " << endl;
            if (aux->siguiente == nullptr) {
                cout << "nullptr" << endl;
            }
            else {
                aux->siguiente->valor->print();
            }
            aux = aux->siguiente;
        }
    }


    T getPos(int pos) {
        if (cant > 0) {
            Node<T>* aux = inicio;
            if (pos >= 0 && pos < cant) {
                for (int i = 0; i < pos; ++i) {
                    aux = aux->siguiente;
                }
            }
            else if (pos < 0 && -pos < cant) {
                for (int i = 0; i > pos; --i) {
                    aux = aux->anterior;
                }
            }
            return aux->valor;
        }

    }

};
//********************************************************************hash_table******************************************************
template <class G, class T>
class HashEntidad {
private:
    G key;
    T value;

public:

    HashEntidad() {}
    HashEntidad(G key, T value) {
        this->key = key;
        this->value = value;
    }
    G getKey() {
        return key;
    }
    T getValue() {
        return value;
    }

};
template <class G, class T>
class HashTabla {
private:
    HashEntidad<G, T>** tabla;
    int numElementos;
    int TABLE_SIZE;

public:
    class iterator {
    private:
        long pos;
        HashEntidad<G, T>** aux;
    public:
        iterator(long pos = 0, HashEntidad<G, T>** aux = nullptr) {
            this->pos = pos;
            this->aux = aux;

        }

        bool operator !=(iterator x) { return this->pos != x.pos; };
        void operator ++() { pos++; };
        T operator*() {
            return aux->value;
        }
    };

    iterator begin() {
        return iterator(0, tabla);
    }
    iterator end() {
        return iterator(numElementos, nullptr);
    }
    HashTabla(int TABLE_SIZE = 128) {
        this->TABLE_SIZE = TABLE_SIZE;
        tabla = new HashEntidad<G, T> * [TABLE_SIZE];
        for (int i = 0; i < TABLE_SIZE; ++i) {
            tabla[i] = nullptr;
        }
        numElementos = 0;
    }
    ~HashTabla()
    {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            if (tabla[i] != nullptr) {
                delete tabla[i];
            }
        }
        delete[] tabla;
    }

    //Direccionamiento seg�n Prueba Lineal
    void insertar(string key, T value) {
        int sum = 0;
        //Hash prima
        int base, step, hash;
        for (size_t i = 0; i < key.length(); i++)
        {
            char x = key.at(i);
            sum += int(x);
        }
        int key2 = sum % 10;
        //validar si la tabla est� llena
        if (numElementos == TABLE_SIZE)return;
        //Funci�n Hash1
        base = key2 % TABLE_SIZE;
        hash = base;
        //constante para Hash2
        step = 0;
        while (tabla[hash] != nullptr)
        {
            //Funci�n Hash2
            hash = (base + step) % TABLE_SIZE;
            step++;
        }
        //almacenarlo en la tabla
        tabla[hash] = new HashEntidad<G, T>(key2, value);
        numElementos++;
    }
    int size() {
        return TABLE_SIZE;
    }
    int sizeactual() {
        return numElementos;
    }

    void mostrar_lambdas(function<void(T)> funcionMostrar) {

        for (int i = 0; i < TABLE_SIZE; ++i) {
            cout << i + 1 << " ";
            if (tabla[i] != nullptr)
                funcionMostrar(tabla[i]->getValue());
            else
                cout << "nullptr" << endl;
        }
    }


};
//********************************************************************hash_table_tipo2********************************************************************

template<typename TK, typename TV>
struct Entry {
    TK key;
    TV value;
    size_t hashcode;
    TK first;
    TV second;
    Entry(TK key, TV value) {
        this->key = key;
        this->value = value;
        first = key;
        second = value;
    }
    Entry() {
        this->key = nullptr;
        this->value = nullptr;
    }

};
template<typename K, typename V>
class Hashiterator {
private:

    Entry<K, V>* posicion_actual;
    int capacidad;
    list<Entry<K, V>>* array;
    pair<K, V>* opcional_actual;

public:
    Hashiterator() { this->posicion_actual = nullptr; }
    Hashiterator& operator++() {
        array++;
        return *this;
    }
    Hashiterator<K, V>& operator=(Hashiterator<K, V> other) {
        this->current = other->current;
        this->array = other.array;
        return (*this);
    }
    bool operator !=(Hashiterator<K, V> other) { return this->posicion_actual != other.posicion_actual; }

};
template<typename TK, typename TV>
class ChainHash
{
public:
    //typedef Hashiterator<TK,TV> iterator;
private:

    list<Entry<TK, TV>>* array;
    int capacity;//tamanio del array
    int size;//cantidad de elementos totales
    int pos;

public:
    ChainHash() {
        // TODO: asignar un tamanio inicial al array
        capacity = 10;
        array = new list<Entry<TK, TV>>[capacity];
        size = 0;
        pos = 0;
    }

    auto begin(int i) {
        return array[i].begin();
    }
    auto end(int i) {
        return array[i].end();
    }
    void set(TK key, TV value) {

        if (fillFactor() >= maxFillFactor) rehashing();
        size_t hashcode = getHashCode(key);//el key transformado numero grande
        int index = hashcode % capacity;//indice de la tabla
        //TODO: insertar el Entry(key, value) en index, manejando colisiones
        //itera desde el inicio 
        for (auto ite = array[index].begin();
            ite != array[index].end();
            ++ite)
        {
            if ((*ite).key == key) {
                (*ite).value = value;
                size++;
                return;
            }
        }
        if (array[index].size() == maxColision) {
            for (int i = 0; i < capacity; i++) {
                ++index;
                index = index % capacity;
                if (array[index].size() != maxColision) {
                    array[index].push_front(Entry<TK, TV>(key, value));
                    size++;
                    return;
                }
            }
        }

        array[index].push_front(Entry<TK, TV>(key, value));
        size++;
    }

    void rehashing() {
        list<Entry<TK, TV>>* temp = new list<Entry<TK, TV>>[capacity];
        for (int i = 0; i < capacity; i++) {
            for (auto ite = array[i].begin(); ite != array[i].end(); ++ite) {
                temp[i].push_front(Entry<TK, TV>((*ite).key, (*ite).value));
            }
        }
        delete[]array;
        array = new list<Entry<TK, TV>>[2 * capacity];


        size = 0;
        capacity = capacity * 2;

        for (int i = 0; i < (capacity / 2); ++i) {
            for (auto ite = temp[i].begin(); ite != temp[i].end(); ++ite) {
                set((*ite).key, (*ite).value);
            }
        }
    }

    int bucket_count() {
        return capacity;
    }
    int bucket_size(int i) {
        return array[i].size();
    }

private:
    double fillFactor() {
        return size / (capacity * maxColision);
    }

    size_t getHashCode(TK key) {
        std::hash<TK> ptr_hash;
        return ptr_hash(key);
    }


};

//********************************************************************todas_las_funciones_en_una_clase******************************************************
class Register {
    string usuario, acreedor, fecha;
    long pago;
public:

    Register(string usuario = "", long pago = 0, string acreedor = "", string fecha = "") {
        this->pago = pago;
        this->usuario = usuario;
        this->acreedor = acreedor;
        this->fecha = fecha;
    }
    void print() {
        cout << usuario << " " << pago << " " << acreedor << " " << fecha << endl;
    }
    string getU() {
        return usuario;
    }
    string getUsuario() {
        return usuario;
    }
    string getPago() {
        return to_string(pago);
    }
    string getAcreedor() {
        return acreedor;
    }
    string getfecha() {
        return fecha;
    }
    long gettran() {
        return pago;
    }
    bool operator<(const Register& r) {
        return this->pago < r.pago;
    }

    friend ostream& operator<<(ostream& os, const Register& dt)
    {
        os << dt.usuario << " " ;
        return os;
    }

    bool operator>=(const Register& r) {
        return this->pago >= r.pago;
    }
    bool operator==(const Register& r) {
        return this->pago == r.pago;
    }
    bool operator>(const Register& r) {
        return this->pago > r.pago;
    }
};
class Dataset {
    BC<Register*> registros;
    ArbolB<Register>* arbolmensaje;
    arbolAVL<Register*, string>* arbolacreedor;//acredor getAcreedor
    arbolAVL<Register*, string>* arbolusuario;//usuario getUsuario
    arbolAVL<Register*, string>* arbolpago;//pago getPago
    arbolAVL<Register*, string>* arbolfecha;//fecha getfecha
    arbolAVL<Register*, string>* buscar_usuario_mostrandoregristro;
    arbolAVL<Register*, long>* arbolsuma;//acredor getAcreedor


    BC<vector<Register>> insertar_sin_puntero;
    BC<vector<Register>>::iterator lista_vector_regis;
    vector<Register>::iterator vector_refgis;

    HashTabla<int, Register*>* ht;
    ChainHash<int, Register*>* hash2;
    ChainHash<string, string> hash;


    vector<Register> grande;
    vector<Register>::iterator it;

public:

    Dataset() {
        this->arbolmensaje = new ArbolB<Register>([](Register r, Register r2) {
            if (r == r2) return 0;
            else if (r < r2) return -1;
            else return 1;    });
        readTSV("Base.csv");
        auto valor = [](Register* e) {return e->getAcreedor(); };
        arbolacreedor = new arbolAVL<Register*, string>(valor);
        auto valor1 = [](Register* e) {return e->getUsuario(); };
        arbolusuario = new arbolAVL<Register*, string>(valor1);
        auto valor2 = [](Register* e) {return e->getPago(); };
        arbolpago = new arbolAVL<Register*, string>(valor2);
        auto valor3 = [](Register* e) {return e->getfecha(); };
        arbolfecha = new arbolAVL<Register*, string>(valor3);

        auto valor4 = [](Register* e) {return e->getUsuario(); };
        buscar_usuario_mostrandoregristro = new arbolAVL<Register*, string>(valor4);
        auto valor5 = [](Register* e) {return e->gettran(); };
        arbolsuma = new arbolAVL<Register*, long>(valor5);
    }

    void readTSV(string name = "", bool header = true) {//campos separados por tab o espacios
        srand(time(NULL));
        ht = new HashTabla<int, Register*>(9);
        hash2 = new ChainHash<int, Register*>();
        ifstream file(name);
        string reg, usuario, acreedor, fecha, t_pago;
        long pago;
        int a = 0;
        if (header)
            getline(file, reg);
        while (getline(file, reg)) {
            stringstream stream(reg);
            getline(stream, usuario, ',');
            getline(stream, t_pago, ',');
            getline(stream, acreedor, ',');
            getline(stream, fecha);
            pago = stoul(t_pago);
            registros.push_back(new Register(usuario, pago, acreedor, fecha));
            grande.push_back(Register(usuario, pago, acreedor, fecha));
            insertar_sin_puntero.push_back(grande);
            ht->insertar("key", new Register(usuario, pago, acreedor, fecha));
            hash2->set(a++, new Register(usuario, pago, acreedor, fecha));

        }
    }
    void showall() {

        registros.printdatos();
    }
    int size() {
        return registros.getCant();
    }
    void printTree() {
        auto l1 = [](Register a) {cout << a.getUsuario() << " "; };
        arbolmensaje->enOrden1(l1);
    }
    void printarbolacreedor() {
        auto l1 = [](Register a) {cout << a.getAcreedor() << " "; };
        arbolmensaje->enOrden1(l1);
    }
    void indexarArboles()
    {
        for (auto e : registros)
        {
            arbolacreedor->add(e);
            arbolusuario->add(e);
            arbolpago->add(e);
            arbolfecha->add(e);
            buscar_usuario_mostrandoregristro->add(e);
            arbolsuma->add(e);
        };
    }
    void mostrarArbolAcreedor()
    {
        auto print = [](Register* e) {cout << e->getAcreedor() << " "; };
        arbolacreedor->inOrder(print);
    }
    void mostrarArbolUsuario()
    {
        auto print = [](Register* e) {cout << e->getUsuario() << " "; };
        arbolusuario->inOrder(print);
    }
    void mostrarArbolPago()
    {
        auto print = [](Register* e) {cout << e->getPago() << " "; };
        arbolpago->inOrder(print);
    }
    void mostrarArbolFecha()
    {
        auto print = [](Register* e) {cout << e->getfecha() << " "; };
        arbolfecha->inOrder(print);
    }
    void buscarUsuarioEnRegistro(string a) {
        //va mostrar ordenado

        auto print = [&a](Register* e) {string b = a;
        if (e->getAcreedor() == b || e->getUsuario() == b) { cout << e->getUsuario() << " " << e->getPago() << " " << e->getAcreedor() << " " << e->getfecha() << " " << endl; } };
        buscar_usuario_mostrandoregristro->inOrder(print);
    }
    void buscarUsuarioSuma(string a) {
        //va mostrar ordenado
        long c = 0;
        auto print = [&a, &c](Register* e) {string b = a;
        if (e->getUsuario() == b) { c = c + e->gettran(); cout << c << "\n"; } };
        buscar_usuario_mostrandoregristro->inOrder(print);

    }
    void mostrarListaDeVectores() {

        for (lista_vector_regis = insertar_sin_puntero.begin(); lista_vector_regis != insertar_sin_puntero.end(); ++lista_vector_regis)
        {
            vector<Register> si = (*lista_vector_regis);
            for (vector_refgis = si.begin(); vector_refgis != si.end(); ++vector_refgis)
            {

                (*vector_refgis).print();
            }
        }
    }
    void mostrarht() {
        auto l1 = [](Register* p) {p->print(); };
        ht->mostrar_lambdas(l1);
    }
    void mostrarHashCoin() {
        for (unsigned i = 0; i < hash2->bucket_count(); ++i){
            cout << "bucket #" << i << " contains " << hash2->bucket_size(i) << " elements: ";
            for (auto it = hash2->begin(i); it != hash2->end(i); ++it)
            cout  << it->first << " -> "<< it->second->getUsuario();
            cout << "\n";
        }
    }
    Register* agregar_tran() {
        ifstream archivo("Base.csv");
        string linea, texto, transaccion;
        while (getline(archivo, linea)) {
            texto = texto + linea + "\n";
        }
        archivo.close();
        cout << "Ingrese su nueva transaccion" << endl;
        cin >> transaccion;
        ofstream modificacion("Base.csv");
        modificacion << texto << transaccion;
        archivo.close();
        return new Register(texto, 1, texto, texto);
    }


};
int main() {
    //eston son los arboles ordenados por y son independientes ya que puedo mostrar todo el registro
    Dataset ds;
    ds.indexarArboles();
    int op = 0;
    string usuario_;

    while (op != 13) {
        cout << "      MENU          " << endl;
        cout << "Listado de Funciones" << endl;
        cout << "1.Mostrar Blockchain" << endl;
        cout << "2.Mostrar cantidad de mensajes" << endl;
        cout << "3.Mostrar arbol acreedor" << endl;
        cout << "4.Mostrar arbol usuario" << endl;
        cout << "5.Mostrar arbol pago" << endl;
        cout << "6.Mostrar arbol fecha" << endl;
        cout << "7.Buscar usuario " << endl;
        cout << "8.Mostrar lista de vectores " << endl;
        cout << "9.Mostrar Hash " << endl;
        cout << "10.Mostrar Suma por Usuario" << endl;
        cout << "11.Agregar Transaccion" << endl;
        cout << "12.Mostrar Hash2" << endl;
        cout << "13.SALIR" << endl;
        cout << "Ingrese una opcion: ";
        cin >> op;
        switch (op) {

        case 1: system("cls"); ds.showall(); system("pause"); system("cls"); cout << "\n" << "\n"; break;
        case 2: system("cls"); cout << "Cantidad de mensajes: " << ds.size() << endl; system("pause"); system("cls"); cout << "\n"; break;
        case 3: system("cls"); ds.mostrarArbolAcreedor(); system("pause"); system("cls"); cout << "\n"; break;
        case 4: system("cls"); ds.mostrarArbolUsuario(); system("pause"); system("cls"); cout << "\n"; break;
        case 5: system("cls"); ds.mostrarArbolPago(); system("pause"); system("cls"); cout << "\n";  break;
        case 6: system("cls"); ds.mostrarArbolFecha(); system("pause"); system("cls"); cout << "\n";  break;
        case 7: system("cls");
            cout << "ingrese el usuario: "; cin >> usuario_; system("cls");
            ds.buscarUsuarioEnRegistro(usuario_); system("pause"); system("cls"); cout << "\n";  break;
        case 8: system("cls"); ds.mostrarListaDeVectores(); system("pause"); system("cls"); cout << "\n";  break;
        case 9: system("cls"); ds.mostrarht(); system("pause"); system("cls"); cout << "\n";  break;
        case 10: system("cls");
            cout << "ingrese el usuario: "; cin >> usuario_; system("cls");
            ds.buscarUsuarioSuma(usuario_); system("pause"); system("cls"); cout << "\n";  break;
        case 11:system("cls"); ds.agregar_tran(); system("pause"); system("cls"); cout << "\n";  break;
        case 12:system("cls"); ds.mostrarHashCoin(); system("pause"); system("cls"); cout << "\n";  break;

        }

    }
    system("pause>0");
    return 0;
}
