#include <ctime>
#include <cstdlib>
#include <functional>
#include <iostream>
#include<algorithm>
using namespace std;

//*******************************************************************Nodo_sencillo******************************************************

template <class T>

class Nodo {
public:
	T elemento;
	Nodo* izq;
	Nodo* der;
	int h;
	Nodo(T elemento) {
		this->elemento = elemento;
		izq = der = nullptr;
		h = 0;

	}
	static int altura(Nodo<T>* n) {
		return n == nullptr ? -1 : n->h;
	}
	void actualizarAltura() {
		h = std::max(altura(der), altura(izq));
	}
};


template <class T>
class ArbolB {
	Nodo<T>* raiz;
	function<int(T, T)> comparar;
private:

	int _altura(Nodo<T>* nodo) {
		if (nodo == nullptr) return 0;
		else
		{
			int izquierda = 1 + _altura(nodo->izq);
			int derecha = 1 + _altura(nodo->izq);
			return std::max(izquierda, derecha);
		}
	}

	void rotarDerecha(Nodo<T>*& nodo) {
		Nodo<T>* p = nodo->izq;
		nodo->izq = p->der;
		nodo->actualizarAltura();
		p->der = nodo;
		nodo = p;
		nodo->actualizarAltura();
	}

	void rotarIzquierda(Nodo<T>*& nodo) {
		Nodo<T>* p = nodo->der;
		nodo->der = p->izq;
		nodo->actualizarAltura();
		p->izq = nodo;
		nodo = p;
		nodo->actualizarAltura();
	}
	void balancear(Nodo<T>*& nodo) {
		int dif = Nodo<T>::altura(nodo->izq) - Nodo<T>::altura(nodo->der);
		if (dif > 1) {
			int hdi = Nodo<T>::altura(nodo->der->izq);
			int hdd = Nodo<T>::altura(nodo->der->der);
			if (hdi > hdd) {
				rotarDerecha(nodo->der);
			}
			rotarIzquierda(nodo);
		}
		if (dif < -1) {
			int hii = Nodo<T>::altura(nodo->izq->izq);
			int hid = Nodo<T>::altura(nodo->izq->der);
			if (hii < hid) {
				rotarIzquierda(nodo->izq);
			}
			rotarDerecha(nodo);
		}
	}

	void _insertar(Nodo<T>*& nodo, T e) {
		if (nodo == nullptr) {
			nodo = new Nodo<T>(e);
		}
		else if (e < nodo->elemento) {
			return _insertar(nodo->izq, e);
		}
		else if (e >= nodo->elemento) {
			return _insertar(nodo->der, e);
		}
		balancear(nodo);
	}
	void _enOrden(Nodo<T>* nodo, function<void(T)>leer) {
		if (nodo == nullptr) return;
		_enOrden(nodo->izq, leer);
		leer(nodo->elemento);
		_enOrden(nodo->der, leer);
	}

	void _enOrden(Nodo<T>* nodo) {
		if (nodo == nullptr) return;
		_enOrden(nodo->izq);
		cout << nodo->elemento << " ";
		_enOrden(nodo->der);
	}

	int _cantidad(Nodo<T>* nodo) {
		if (nodo == nullptr)
			return 0;
		else
		{
			int ci, cd;
			ci = _cantidad(nodo->izq);
			cd = _cantidad(nodo->der);
			return 1 + ci + cd;
		}
	}

	int compara(T e1, T e2) {
		if (e1 == e2) return 0;
		else if (e1 < e2) return 1;
		else return -1;
	}
	bool _buscar(Nodo<T>* nodo, T e) {
		if (nodo == nullptr)
			return false;
		else {
			int r = compara(nodo->elemento, e);
			if (r == 0)
				return true;
			else
				if (r < 0)
					return _buscar(nodo->der, e);
				else
					return _buscar(nodo->izq, e);
		}
	}
	T minimo(Nodo<T>* nodo) {
		if (nodo->izq == nullptr)
			return nodo->elemento;
		else
			return minimo(nodo->izq);
	}

	Nodo<T>* getmin(Nodo<T>* nodo)
	{
		Nodo<T>* curr = nodo;

		while (curr && curr->izq) {
			curr = curr->izq;
		}
		return curr;
	}

	Nodo<T>* deleteNode(Nodo<T>*& nodo, T elemento)
	{
		if (nodo == nullptr)
			return nodo;

		if (elemento < nodo->elemento)
			nodo->izq = deleteNode(nodo->izq, elemento);

		else if (elemento > nodo->elemento)
			nodo->der = deleteNode(nodo->der, elemento);
		else {
			if (nodo->izq == nullptr) {
				Nodo<T>* temp = nodo->der;
				delete(nodo);
				return temp;
			}
			else if (nodo->der == nullptr) {
				Nodo<T>* temp = nodo->izq;
				delete(nodo);
				return temp;
			}

			Nodo<T>* temp = getmin(nodo->izq);

			nodo->elemento = temp->elemento;
			nodo->izq = deleteNode(nodo->izq, temp->elemento);
		}
		return nodo;
	}

public:
	ArbolB() {
		raiz = nullptr;
	}
	ArbolB(function<int(T, T)> comparar) : comparar(comparar) {

		raiz = nullptr;
	}
	void insertar(T e) {
		return _insertar(raiz, e);
	}
	void enOrden() {
		_enOrden(raiz);
	}
	void enOrden1(function<void(T)>leer) {
		_enOrden(raiz, leer);
	}

	int cantidad() {
		return _cantidad(raiz);
	}
	int Altura() {
		return altura(raiz);
	}
	void deleteNodo(T e) {
		deleteNode(raiz, e);
	}
	T Minimo() {
		return minimo(raiz);
	}
	bool buscar(T e) {

		return _buscar(raiz, e);

	}
};
//********************************************************************Nodo_2_parametros******************************************************
template<typename T, typename R>
class arbolAVL
{
	struct Node
	{
		T element;
		Node* left;
		Node* right;
		int height;

		Node(T element) :element(element), left(nullptr), right(nullptr), height(0) {}
	};
	T NONE = 0;
	Node* root;
	function<R(T)>key;
	int len;
public:
	arbolAVL(function<R(T)>key = [](T a) {return a; }) :key(key), root(nullptr), len(0) {}
	~arbolAVL() { clear(root); }
	void clear() { clear(root); len = 0; }
	void add(T elem) { add(root, elem); }
	int height() { return height(root); }
	int size() { return len; }
	void inOrder(function<void(T)>proc) { inOrder(root, proc); }
	T find(R val) { return find(root, val); }
private:
	void clear(Node*& node)
	{
		if (node != nullptr)
		{
			clear(node->left);
			clear(node->right);
			delete node;
			node = nullptr;
		}
	}
	int height(Node* node)
	{
		return node == nullptr ? -1 : node->height;
	}
	void add(Node*& node, T elem)
	{
		if (node == nullptr)
		{
			node = new Node(elem);
			++len;
		}
		else
		{
			if (key(elem) < key(node->element))
			{
				add(node->left, elem);
			}
			else
			{
				add(node->right, elem);
			}
			balance(node);
		}
	}
	T find(Node* node, R val)
	{
		if (node == nullptr)
		{
			return NONE;
		}
		else if (val == key(node->element))
		{
			return node->element;
		}
		else if (val < key(node->element))
		{
			return find(node->left, val);
		}
		else
		{
			return find(node->right, val);
		}
	}
	void inOrder(Node* node, function<void(T)>proc)
	{
		if (node != nullptr)
		{
			inOrder(node->left, proc);
			proc(node->element);
			inOrder(node->right, proc);
		}
	}
	void updateHeight(Node* node)
	{
		if (node != nullptr)
		{
			int hl = height(node->left);
			int hr = height(node->right);

			node->height = max(hl, hr) + 1;
		}
	}
	void rotateLeft(Node*& node)
	{
		Node* aux = node->right;
		node->right = aux->left;
		updateHeight(node);
		aux->left = node;
		updateHeight(aux);
		node = aux;
	}
	void rotateRight(Node*& node)
	{
		Node* aux = node->left;
		node->left = aux->right;
		updateHeight(node);
		aux->right = node;
		updateHeight(aux);
		node = aux;
	}
	void balance(Node*& node)
	{
		int hl = height(node->left);
		int hr = height(node->right);
		if (hr - hl < -1)
		{
			hl = height(node->left->left);
			hr = height(node->left->right);
			if (hr > hl)
			{
				rotateLeft(node->left);
			}
			rotateRight(node);
		}
		else if (hr - hl > 1)
		{
			hl = height(node->right->left);
			hr = height(node->right->right);
			if (hl > hr)
			{
				rotateRight(node->right);
			}
			rotateLeft(node);
		}
		else
		{
			updateHeight(node);
		}
	}
};